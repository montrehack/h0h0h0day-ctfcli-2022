def gift(gift = None):
    if gift is None:
        return print
    elif gift == "gift":
        with open("flag.txt", "r") as flag:
            return flag.read()
    else:
        return "gift"