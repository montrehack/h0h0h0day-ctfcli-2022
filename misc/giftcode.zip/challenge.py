#!/usr/bin/python3
import sys
import socket
from multiprocessing import Process
from types import CodeType

def run_challenge(conn):
    sys.stdout = conn.makefile("w")

    try:
        print("Happy Holidays!")
        print("Do you have a gift for me?")
        gift = conn.recv(100)
        print("If you've been good, I'll give you a gift too!")

        # Simple Christmas spirit test
        if not all([b < 2 or b in "áppí âlídeZ".encode("cp437") for b in gift]):
            print("That's not very Christmas of you :(")
            conn.close()
            exit(1)

        module = CodeType(
            0,                  # co_argcount
            0,                  # co_posonlyargcount
            0,                  # co_kwonlyargcount
            0,                  # co_nlocals
            256,                # co_stacksize
            0,                  # co_flags
            gift,               # co_code
            (0, None),          # co_consts
            ("gift",),          # co_names
            (),                 # co_varnames
            "challenge",        # co_filename
            "challenge",        # co_name
            0,                  # co_firstlineno
            b"",                # co_linetable
            (),                 # co_freevars
            ()                  # co_cellvars   
        )
        exec(module, {}, {})

    except Exception as e:
        print(f"{e}".encode())
    finally:
        conn.close()


def main():
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(('0.0.0.0', 4444))
    s.listen(100)

    while True:
        conn, _ = s.accept()
        Process(target=run_challenge, args=(conn,)).start()
        conn.close()


if __name__ == "__main__":
    main()